<?php 

/**** WooCommerce ****/
if (class_exists('woocommerce')) {

  add_action( 'after_setup_theme', 'woocommerce_support' );
  function woocommerce_support() {
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
  }
  
  add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 9;' ), 20 );
  // breadcrumb woocommerce
  remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
  add_action('breadcrumb_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

/**
  * Wrap add to cart text
  * Open a div
  *
  * @since 1.0
  */
 function add_to_cart_text( $text, $product ) {

  if(  $product->product_type == 'simple' ) {

   
    if( $product->is_purchasable() && $product->is_in_stock() ) {
     $text = esc_html__('take this course', 'learn');
    }

  }

  return $text;
 }

add_filter( 'woocommerce_product_single_add_to_cart_text', 'add_to_cart_text' , 10, 2 );

//remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );


add_filter('woocommerce_product_get_rating_html', 'get_rating_all', 10, 2);

function get_rating_all($rating_html, $rating) {
  if ( $rating > 0 ) {
    $title = sprintf( __( 'Rated %s out of 5', 'woocommerce' ), $rating );
  } else {
    $title = 'Not yet rated';
    $rating = 0;
  }

  $rating_html  = '<div class="star-rating" title="' . $title . '">';
  $rating_html .= '<span style="width:' . ( ( $rating / 5 ) * 100 ) . '%"><strong class="rating">' . $rating . '</strong> ' . __( 'out of 5', 'woocommerce' ) . '</span>';
  $rating_html .= '</div>';

  return $rating_html;
}

add_image_size( 'xxx-zzz', 220, 140, true );

// Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
  if (!function_exists('loop_columns')) {
  function loop_columns() {
   return 3; // 3 products per row
  }
}

if (  ! function_exists( 'woocommerce_template_loop_product_title' ) ) {
    /**
     * Show the product title in the product loop. By default this is an H3.
     */
    function woocommerce_template_loop_product_title() {
        echo '<h3 class="woocommerce-loop-product__title">' . get_the_title() . '</h3>'; 
    }
}