﻿var courses = {
	"Al": "Alphabetical",
	"Bi": "Biology",
    "Co": "Course",
    "Cl": "Class",
    "Ed": "Educational"
}